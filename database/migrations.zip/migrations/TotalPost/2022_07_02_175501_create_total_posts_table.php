<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTotalPostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('total_posts', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('numberParcel');
            $table->bigInteger('userId')->unsigned();
            $table->foreign('userId')
                ->references('id')->on('users')
                ->onDelete('no action');
            $table->bigInteger('addressId')->unsigned();
            $table->foreign('addressId')
                ->references('id')->on('addresses')
                ->onDelete('no action');
            $table->bigInteger('typeSerId')->unsigned();
            $table->foreign('typeSerId')
                ->references('id')->on('services')
                ->onDelete('no action');
            $table->integer('cost')->default(0);
            $table->string('status');
            $table->boolean('printFactor');
            $table->string('discountCouponCode')->nullable();
            $table->boolean('hasNotifRequest')->nullable();
            $table->boolean('RequestPrintAvatar')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('total_posts');
    }
}
