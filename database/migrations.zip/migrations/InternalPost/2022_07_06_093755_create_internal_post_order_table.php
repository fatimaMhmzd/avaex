<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInternalPostOrderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('internal_post_order', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('internalPostId')->unsigned();
            $table->foreign('internalPostId')
                ->references('id')->on('internal_posts')
                ->onDelete('no action');
            $table->string('shipment');
            $table->float('Weight');
            $table->float('width')->nullable();
            $table->float('height')->nullable();
            $table->float('lenght')->nullable();
            $table->float('Value');
            $table->integer('boxnumber')->default(1);
            $table->string('typeId');
            $table->bigInteger('sizeId')->unsigned()->nullable();
            $table->foreign('sizeId')
                ->references('id')->on('packagings')
                ->onDelete('no action');
            $table->boolean('needKarton');
            $table->bigInteger('insuranceId')->unsigned();
            $table->foreign('insuranceId')
                ->references('id')->on('insurances')
                ->onDelete('no action');
            $table->bigInteger('serviceId')->unsigned();
            $table->foreign('serviceId')
                ->references('id')->on('compony_services')
                ->onDelete('no action');
            $table->bigInteger('getterAddressId')->unsigned();
            $table->foreign('getterAddressId')
                ->references('id')->on('addresses')
                ->onDelete('no action');
            $table->integer('price')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('internal_post_order');
    }
}
