<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddressesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addresses', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('userId')->unsigned();
            $table->foreign('userId')
                ->references('id')->on('users')
                ->onDelete('no action');
            $table->bigInteger('cityId')->unsigned();
            $table->foreign('cityId')
                ->references('id')->on('cities')
                ->onDelete('no action');
            $table->bigInteger('provinceId')->unsigned();
            $table->foreign('provinceId')
                ->references('id')->on('provinces')
                ->onDelete('no action');
            $table->bigInteger('countryId')->unsigned();
            $table->foreign('countryId')
                ->references('id')->on('countries')
                ->onDelete('no action');
            $table->string('address');
            $table->string('postCode');
            $table->string('name');
            $table->string('family');
            $table->string('phone');
            $table->string('email')->nullable();
            $table->string('compony')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addresses');
    }
}
