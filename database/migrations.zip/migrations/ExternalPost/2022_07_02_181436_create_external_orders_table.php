<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExternalOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('external_orders', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('externalPostId')->unsigned();
            $table->foreign('externalPostId')
                ->references('id')->on('external_posts')
                ->onDelete('no action');
            $table->string('shipment');
            $table->float('Weight');
            $table->float('width');
            $table->float('height');
            $table->float('lenght');
            $table->float('Value');
            $table->string('brand')->nullable();
            $table->string('Link')->nullable();
            $table->integer('boxnumber')->default(1);
            $table->string('typeId');
            $table->bigInteger('sizeId')->unsigned();
            $table->foreign('sizeId')
                ->references('id')->on('packagings')
                ->onDelete('no action');
            $table->boolean('needKarton');
            $table->bigInteger('insuranceId')->unsigned();
            $table->foreign('insuranceId')
                ->references('id')->on('insurances')
                ->onDelete('no action');
            $table->string('image1');
            $table->string('image2');
            $table->string('image3');
            $table->bigInteger('serviceId')->unsigned();
            $table->foreign('serviceId')
                ->references('id')->on('compony_services')
                ->onDelete('no action');
            $table->boolean('isUsed')->nullable();

            $table->bigInteger('getterAddressId')->unsigned();
            $table->foreign('getterAddressId')
                ->references('id')->on('addresses')
                ->onDelete('no action');

            $table->integer('price');
            $table->softDeletes();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('external_orders');
    }
}
