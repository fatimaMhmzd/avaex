<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateComponyTypePostTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('compony_type_post', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('componyId')->unsigned();
            $table->foreign('componyId')
                ->references('id')->on('componies')
                ->onDelete('no action');
            $table->string('name');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('compony_type__post');
    }
}
